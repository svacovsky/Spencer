import React from 'react'

const NoData = () => <div className="fs-18">There’s no data at this time.</div>

export default NoData
