/* eslint import/prefer-default-export: 0 */

export const slugify = str => str.toLowerCase().replace(/\s+/g, '-')
