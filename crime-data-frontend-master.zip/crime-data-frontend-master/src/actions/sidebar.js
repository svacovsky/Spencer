import { SIDEBAR_HIDE, SIDEBAR_SHOW } from './constants'

export const hideSidebar = () => ({ type: SIDEBAR_HIDE })
export const showSidebar = () => ({ type: SIDEBAR_SHOW })
