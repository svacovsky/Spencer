import { MODAL_HIDE, MODAL_SHOW } from './constants'

export const hideModal = () => ({ type: MODAL_HIDE })
export const showModal = () => ({ type: MODAL_SHOW })
