import { FEEDBACK_HIDE, FEEDBACK_SHOW } from './constants'

export const hideFeedback = () => ({ type: FEEDBACK_HIDE })
export const showFeedback = () => ({ type: FEEDBACK_SHOW })
